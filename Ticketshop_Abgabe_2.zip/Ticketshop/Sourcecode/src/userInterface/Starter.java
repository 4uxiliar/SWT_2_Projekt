package userInterface;

import controller.DatenbankController;
import controller.ViewController;

import java.sql.SQLException;

public class Starter {

    public static void main(String[] args) {

        ViewController.getInstance();
    }
}
