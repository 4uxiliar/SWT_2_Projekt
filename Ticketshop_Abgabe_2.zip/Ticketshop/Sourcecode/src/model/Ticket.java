package model;

public class Ticket {
    private long ticketnummer;
    private double preis;

    public long getTicketnummer() {
        return ticketnummer;
    }

    public void setTicketnummer(long ticketnummer) {
        this.ticketnummer = ticketnummer;
    }

    public double getPreis() {
        return preis;
    }

    public void setPreis(double preis) {
        this.preis = preis;
    }
}
