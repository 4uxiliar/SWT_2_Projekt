package model;

public enum Platztyp {
    SITZPLATZ,
    STEHPLATZ
}
